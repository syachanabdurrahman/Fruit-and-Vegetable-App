package com.example.learnlistview;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class CustumListAdapter extends ArrayAdapter<String> {
    private final Activity context;
    private final String[] judulList;
    private final Integer[] gambarList;


    public CustumListAdapter(Activity context, String[] judulList, Integer[] gambarList) {
        super(context, R.layout.row_item,judulList);
        this.context = context;
        this.judulList = judulList;
        this.gambarList = gambarList;
    }

    public View getView(int position, View view, ViewGroup viewGroup){
        // Memanggil layout untuk data
        LayoutInflater inflater = context.getLayoutInflater();
        View rowView = inflater.inflate(R.layout.row_item,null,true);

        //memanggil widget-widget dari layout yang kita panggil
        TextView textList = rowView.findViewById(R.id.txt_list);
        ImageView imageList = rowView.findViewById(R.id.image_list);

        //mensinkronisasi dengan model yang di buat

        textList.setText(judulList[position]);
        imageList.setImageResource(gambarList[position]);

        return rowView;

    }
}



