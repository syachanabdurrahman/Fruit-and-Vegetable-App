package com.example.learnlistview;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.IOException;
public class ActivityListView extends AppCompatActivity {
    ListView listView;

    String[] judulList = {
            "Alpukat",
            "Apel",
            "Ceri",
            "Durian",
            "JambuAir",
            "Manggis",
            "Strawberry"
    };

    Integer[] gambarList = {
            R.drawable.alpukat,
            R.drawable.apel,
            R.drawable.ceri,
            R.drawable.durian,
            R.drawable.jambuair,
            R.drawable.manggis,
            R.drawable.strawberry,
    };

    int[] list_musik = {
            R.raw.alpukat,
            R.raw.apel,
            R.raw.ceri,
            R.raw.durian,
            R.raw.jambuair,
            R.raw.manggis,
            R.raw.strawberry
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view);

        //dekrarasi listview
        listView = findViewById(R.id.list_view);

        //memanggil Adapter untuk memunculkan data
        CustumListAdapter adapter = new CustumListAdapter(this,judulList,gambarList);
        listView.setAdapter(adapter);

        //perintah agar data dalam bentuk list bisa diklik
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Toast berfungsi untuk membuat pesan singkat
                Toast.makeText(getApplicationContext(), "anda memilih :" + judulList[position],
                        Toast.LENGTH_SHORT).show();
                //Uri untuk mediaplayer
                Uri myUri = Uri.parse("android.resource://" + getPackageName() + "/" + list_musik[position]);
                MediaPlayer mediaPlayer = new MediaPlayer();
                mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                try {
                    mediaPlayer.setDataSource(getApplicationContext(), myUri);
                }catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    mediaPlayer.prepare();
                }catch (IOException e){
                    e.printStackTrace();
                    }
                    mediaPlayer.start();
                }
        });
    }
}
