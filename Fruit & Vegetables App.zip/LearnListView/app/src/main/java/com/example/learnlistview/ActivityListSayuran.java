package com.example.learnlistview;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class ActivityListSayuran extends AppCompatActivity {
    ListView listSayur;

    String[] judulList = {
            "Bayam",
            "Kembang Kol",
            "Lobak Putih",
            "Lobak Ungu",
            "Terung",
            "Tomat",
            "Wortel"
    };

    Integer[] gambarList = {
            R.drawable.bayam,
            R.drawable.kembangkol,
            R.drawable.lobakputih,
            R.drawable.lobakungu,
            R.drawable.terung,
            R.drawable.tomat,
            R.drawable.wortel
    };



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_sayuran);

        //dekrarasi listview
        listSayur = findViewById(R.id.list_sayur);

        //memanggil Adapter untuk memunculkan data
        CustumListAdapter adapter = new CustumListAdapter(this,judulList,gambarList);
        listSayur.setAdapter(adapter);

        //perintah agar data dalam bentuk list bisa diklik
        listSayur.setOnItemClickListener( new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Toast berfungsi untuk membuat pesan singkat
                Toast.makeText(getApplicationContext(), "anda memilih:" + judulList[position],
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}
